import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: FoodPortion()));

class FoodPortion extends StatelessWidget {
  const FoodPortion({super.key});
  @override
  Widget build(BuildContext context) {
    return Stack(children: <Widget>[
      Image.asset(
        "assets/foodpagebg.png",
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        fit: BoxFit.cover,
      ),
      Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: SizedBox(
              width: double.infinity,
              height: 30,
            ),
          ),
          Text(
            'Hello Fitsters!',
            style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.normal,
              fontFamily: 'Poppins',
              color: Colors.white,
              decoration: TextDecoration.underline,
              decorationColor: Colors.white,
            ),
          ),
          SizedBox(
            width: double.infinity,
            height: 10,
          ),
          Text(
            'Make Your Own Food',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w200,
              fontFamily: 'Poppins',
              color: Colors.white,
              decoration: TextDecoration.none,
            ),
          ),
          SizedBox(
            height: 70,
          ),
          FloatingActionButton.extended(
            label: Text('Let\'s Go'), // <-- Text
            backgroundColor: Colors.blue,
            icon: Icon(
              // <-- Icon
              Icons.arrow_right_alt_rounded,
              size: 24.0,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CategoriesFood()),
              );
            },
          ),
        ],
      )
    ]);
  }
}

class CategoriesFood extends StatelessWidget {
  const CategoriesFood({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Image.asset(
          "assets/FoodCategoriesBg.png",
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
        ),
        Positioned(
          top: 293,
          left: 0,
          right: 0,
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.blue[200],
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Center(
              child: Text(
                'Top Recipes',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.cyan[900],
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: 100,
          left: 0,
          right: 150,
          child: SizedBox(
            height: 150,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 4,
              itemBuilder: (BuildContext context, int index) {
                final List<Map<String, dynamic>> categoryData = [
                  {
                    'route': Korean(
                      category: 'Korean',
                    ),
                    'image': 'assets/teokbeokie.png',
                    'name': 'Korean',
                  },
                  {
                    'route': Rice(
                      category: 'Rice',
                    ),
                    'image': 'assets/rice1.png',
                    'name': 'Rice',
                  },
                  {
                    'route': Stew(
                      category: 'Stew',
                    ),
                    'image': 'assets/stew1.png',
                    'name': 'Stew',
                  },
                  {
                    'route': Healthy(
                      category: 'Healthy',
                    ),
                    'image': 'assets/salad.png',
                    'name': 'Healthy',
                  },
                ];

                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => categoryData[index]['route'],
                      ),
                    );
                  },
                  child: Container(
                    width: 150,
                    margin: EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: Offset(0, 3),
                        ),
                      ],
                      borderRadius: BorderRadius.circular(10),
                      color: Color(0xff075460),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ClipRRect(
                          //for circular images
                          borderRadius: BorderRadius.circular(20.0),
                          child: Image.asset(
                            categoryData[index]['image'],
                            height: 100,
                            width: 100,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          categoryData[index]['name'],
                          style: TextStyle(
                            color: Colors.white,
                            decoration: TextDecoration.none,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        Positioned(
          top: 45,
          left: 0,
          right: 200,
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.transparent,
            ),
            child: Center(
              child: Text(
                'Categories',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.cyan[900],
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: 360,
          left: 50,
          right: 50,
          child: Container(
            height: 130,
            width: 90,
            decoration: BoxDecoration(
              color: Color(0xff075460),
              borderRadius: BorderRadius.circular(20.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3),
                ),
              ],
              image: DecorationImage(
                image: AssetImage('assets/biryani1.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: Center(
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RiceRecipe()),
                  );
                },
                child: Container(
                  height: 30,
                  width: 90,
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: Center(
                    child: Text(
                      'Biryani',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: 500,
          left: 50,
          right: 50,
          child: Container(
            height: 130,
            width: 90,
            decoration: BoxDecoration(
              color: Color(0xff075460),
              borderRadius: BorderRadius.circular(20.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3),
                ),
              ],
              image: DecorationImage(
                image: AssetImage('assets/greekSalad.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: Center(
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HealthyRecipe()),
                  );
                },
                child: Container(
                  height: 30,
                  width: 150,
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: Center(
                    child: Text(
                      'Greek Salad',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class Korean extends StatelessWidget {
  final String category;
  const Korean({Key? key, required this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(children: <Widget>[
      Image.asset(
        "assets/korean1.png",
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        fit: BoxFit.cover,
      ),
      Positioned(
        top: 150,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/teokbeokie.png'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => KoreanRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 190,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Tteokbbeokie',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 310,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/jigae.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => KoreanRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 150,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Jjigae',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 470,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 250,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/friedchicken.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => KoreanRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 250,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'K-Fried Chicken',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ]);
  }
}

class Stew extends StatelessWidget {
  final String category;
  const Stew({Key? key, required this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(children: <Widget>[
      Image.asset(
        "assets/stew.png",
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        fit: BoxFit.cover,
      ),
      Positioned(
        top: 150,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/nihari.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => StewRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 100,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Nihari',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 310,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/beanstew.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => StewRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 250,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'White Bean Stew',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 470,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 250,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/yakhni.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => StewRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 200,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Chicken Yakhni',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ]);
  }
}

class Healthy extends StatelessWidget {
  final String category;
  const Healthy({Key? key, required this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(children: <Widget>[
      Image.asset(
        "assets/healthy.png",
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        fit: BoxFit.cover,
      ),
      Positioned(
        top: 150,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/acai.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HealthyRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 190,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Acai Bowl',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 310,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/greekSalad.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HealthyRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 150,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Greek Salad',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 470,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 250,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/chickpea.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HealthyRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 250,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Chickpea Salad',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ]);
  }
}

class Rice extends StatelessWidget {
  final String category;
  const Rice({Key? key, required this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(children: <Widget>[
      Image.asset(
        "assets/rice.png",
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        fit: BoxFit.cover,
      ),
      Positioned(
        top: 150,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/biryani1.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RiceRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 190,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Biryani',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 310,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 90,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/kabuli.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RiceRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 150,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Kabuli Pulao',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      Positioned(
        top: 470,
        left: 50,
        right: 50,
        child: Container(
          height: 130,
          width: 250,
          decoration: BoxDecoration(
            color: Color(0xff075460),
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
            image: DecorationImage(
              image: AssetImage('assets/chinese.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RiceRecipe()),
                );
              },
              child: Container(
                height: 30,
                width: 250,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Center(
                  child: Text(
                    'Chinese Rice',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ]);
  }
}

class HealthyRecipe extends StatelessWidget {
  const HealthyRecipe({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff075460),
        automaticallyImplyLeading: true,
        title: Text('Greek Salad Recipe'),
      ),
      body: ListView(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(16.0),
            child: Image.asset('assets/greekSalad.jpg'),
          ),
          Container(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'Ingredients:\n- 2 large tomatoes, diced\n- 1 cucumber, diced\n- 1/2 red onion, thinly sliced\n- 1/2 green bell pepper, diced\n- 1/2 cup kalamata olives\n- 1/2 cup crumbled feta cheese\n- 1/4 cup extra-virgin olive oil\n- 2 tablespoons red wine vinegar\n- 1 teaspoon dried oregano\n- Salt and freshly ground black pepper, to taste\n\nInstructions:\n1. In a large bowl, combine the tomatoes, cucumber, red onion, bell pepper, and olives.\n2. In a small bowl, whisk together the olive oil, red wine vinegar, oregano, salt, and pepper.\n3. Pour the dressing over the salad and toss well to combine.\n4. Add the crumbled feta cheese and gently toss again.\n5. Serve chilled and enjoy!',
              style: TextStyle(fontSize: 18.0),
            ),
          ),
        ],
      ),
    );
  }
}

class KoreanRecipe extends StatelessWidget {
  const KoreanRecipe({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff075460),
        automaticallyImplyLeading: true,
        title: Text('Tteokbokki Recipe'),
      ),
      body: ListView(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(16.0),
            child: Image.asset('assets/teokbeokie.png'),
          ),
          Container(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'Ingredients:\n- 500g tteok (Korean rice cakes)\n- 150g fish cakes\n- 1 onion, sliced\n- 2 green onions, chopped\n- 2 tablespoons gochujang (Korean red pepper paste)\n- 1 tablespoon gochugaru (Korean red pepper flakes)\n- 1 tablespoon sugar\n- 1 tablespoon soy sauce\n- 1 tablespoon minced garlic\n- 1 tablespoon sesame oil\n- 4 cups water\n\nInstructions:\n1. In a large pot, add the water, onion, fish cakes, gochujang, gochugaru, sugar, soy sauce, and minced garlic. Mix well and bring to a boil.\n2. Add the tteok to the pot and stir gently to prevent the rice cakes from sticking together.\n3. Cook for about 10-15 minutes over medium heat until the tteok is cooked and the sauce thickens.\n4. Add the chopped green onions and sesame oil and stir well.\n5. Serve hot and enjoy!',
              style: TextStyle(fontSize: 18.0),
            ),
          ),
        ],
      ),
    );
  }
}

class StewRecipe extends StatelessWidget {
  const StewRecipe({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff075460),
        automaticallyImplyLeading: true,
        title: Text('Chicken Yakhni Recipe'),
      ),
      body: ListView(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(16.0),
            child: Image.asset('assets/yakhni.jpg'),
          ),
          Container(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'Ingredients:\n- 1 kg chicken\n- 2 onions, sliced\n- 1 tbsp ginger paste\n- 1 tbsp garlic paste\n- 1/2 cup yogurt\n- 2 tsp coriander powder\n- 1 tsp cumin seeds\n- 1 tsp fennel seeds\n- 1 tsp black peppercorns\n- 4 cloves\n- 4 green cardamom\n- 1 cinnamon stick\n- Salt to taste\n- 1/4 cup oil\n- 1 liter water\n\nInstructions:\n1. Heat oil in a pot and add sliced onions. Fry until onions are golden brown.\n2. Add chicken and fry for a few minutes until chicken is browned.\n3. Add ginger paste, garlic paste, coriander powder, cumin seeds, fennel seeds, black peppercorns, cloves, green cardamom, cinnamon stick, and salt. Mix well.\n4. Add yogurt and cook for a few minutes until the yogurt is well incorporated.\n5. Add water and bring to a boil.\n6. Reduce heat and let the yakhni simmer for 30-40 minutes or until the chicken is tender and the broth is flavorful.\n7. Serve hot with naan or rice.',
              style: TextStyle(fontSize: 18.0),
            ),
          ),
        ],
      ),
    );
  }
}

class RiceRecipe extends StatelessWidget {
  const RiceRecipe({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff075460),
        automaticallyImplyLeading: true,
        title: Text('Biryani Recipe'),
      ),
      body: ListView(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(16.0),
            child: Image.asset('assets/biryani1.jpg'),
          ),
          Container(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'Ingredients:\n- 1 kg basmati rice\n- 1 kg chicken\n- 2 cups yogurt\n- 2 cups fried onions\n- 1/2 cup ghee\n- 2 tbsp ginger paste\n- 2 tbsp garlic paste\n- 4 bay leaves\n- 6 green cardamom\n- 1 cinnamon stick\n- 1 tsp cumin seeds\n- 1 tsp coriander seeds\n- 1 tsp black peppercorns\n- 1 tsp red chili powder\n- Salt to taste\n\nInstructions:\n1. Soak the rice in water for 30 minutes.\n2. Heat the ghee in a large pot and add the bay leaves, green cardamom, cinnamon stick, cumin seeds, coriander seeds, and black peppercorns. Fry for a few seconds.\n3. Add the chicken, ginger paste, garlic paste, red chili powder, and salt. Cook until the chicken is browned.\n4. Add the yogurt and fried onions, and stir to combine.\n5. Drain the rice and add it to the pot. Add enough water to cover the rice by about 1 inch.\n6. Cover the pot and cook on low heat for 20-25 minutes, or until the rice is cooked and the water has been absorbed.\n7. Serve hot with raita and salad.',
              style: TextStyle(fontSize: 18.0),
            ),
          ),
        ],
      ),
    );
  }
}
